using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace ViewModelFun.Models
{
    public class Users
    {
        public List<string> userList { get; set; }
    }
}