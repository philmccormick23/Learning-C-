using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace ViewModelFun.Models
{
    public class User
    {
        public string FirstName {get;set;}
        public string LastName {get;set;}
    }
}