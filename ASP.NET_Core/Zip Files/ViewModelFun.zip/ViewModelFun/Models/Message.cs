using Microsoft.AspNetCore.Mvc;

namespace ViewModelFun.Models
{
    public class Message
    {
        public string content { get; set; }
    }
}