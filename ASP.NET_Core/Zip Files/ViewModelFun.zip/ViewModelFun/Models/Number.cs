
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace ViewModelFun.Models
{
    public class Numbers
    {
        public List<int> numList { get; set; }
    }
}