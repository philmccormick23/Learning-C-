using Microsoft.AspNetCore.Mvc;
    namespace ProjectName.Controllers     //be sure to use your own project's namespace!
    {
        public class HelloController : Controller   //remember inheritance??
        {
            //for each route this controller is to handle:
            [HttpGet("")]       //type of request   //associated route string (exclude the leading /)
            public string Index()
            {
                return "Hello World from HelloController!";
            }

            
            [HttpGet("route2")]       //type of request //associated route string (exclude the leading /)
            public string Route2()
            {
                return "Routing works";
            }

            [HttpGet("user/{username}/{location}")]       //passing info from the URL
            public string HelloUser(string username, string location)
            {
                return $"Hello {username} from {location}";
            }

        }
    }