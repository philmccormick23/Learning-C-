﻿using System;
using System.Collections.Generic;
using System.Linq;
using JsonData;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //Collections to work with
            List<Artist> Artists = JsonToFile<Artist>.ReadJson();
            List<Group> Groups = JsonToFile<Group>.ReadJson();

            //========================================================
            //Solve all of the prompts below using various LINQ queries
            //========================================================

            //There is only one artist in this collection from Mount Vernon, what is their name and age?

            var MtVernon = Artists.Where(p => p.Hometown == "Mount Vernon").Select(p=> new {p.ArtistName, p.Age}).First();
            System.Console.WriteLine("###############################################");
            System.Console.WriteLine(MtVernon.ArtistName);
            System.Console.WriteLine(MtVernon.Age);

            //Who is the youngest artist in our collection of artists?

            var Earliest = Artists.OrderBy(x => x.Age).FirstOrDefault();
            System.Console.WriteLine("###############################################");
            System.Console.WriteLine(Earliest.ArtistName);

            //Display all artists with 'William' somewhere in their real name
            
            var William=Artists.Where(p=>p.RealName=="William").Select(p=>p.ArtistName);
            System.Console.WriteLine("###############################################");
            IEnumerable<Artist> williams = Artists.Where(p=> p.RealName.Contains("William"));
            foreach (var item in williams)
            {
                System.Console.WriteLine(item.RealName);
            }

            //Display the 3 oldest artist from Atlanta

            IEnumerable<Artist> orderedArtists = Artists.Where(p => p.Hometown =="Atlanta").OrderByDescending(p => p.Age).Take(3);

            System.Console.WriteLine("###############################################");
            foreach (var item in orderedArtists)
            {
                System.Console.WriteLine(item.ArtistName);
            }

            //(Optional) Display the Group Name of all groups that have members that are not from New York City

            //(Optional) Display the artist names of all members of the group 'Wu-Tang Clan'
        }
    }
}
