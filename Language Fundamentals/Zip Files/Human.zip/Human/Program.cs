﻿using System;

namespace Human
{
    class Program
    {
        static void Main(string[] args)
        {
            Human phil = new Human("Phil");
            System.Console.WriteLine(phil.Name);

            Human sam = new Human("Sam", 5, 7, 5, 120);
            Console.WriteLine("Character Name: " + sam.Name + " Health: " + sam.Health + " Intelligence: " + sam.Intelligence + " Dexterity: " + sam.Dexterity + " Strength: " + sam.Strength);
            phil.Attack(sam);
            Console.WriteLine("Character Name: " + sam.Name + " Health: " + sam.Health + " Intelligence: " + sam.Intelligence + " Dexterity: " + sam.Dexterity + " Strength: " + sam.Strength);
        }
    }
}
